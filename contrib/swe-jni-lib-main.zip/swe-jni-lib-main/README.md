# swe-jni-lib

Java-Native-Library (JNI) based on sources of Swiss Ephemeris (Astrodienst AG)
Sources copied from: http://www.astro.com/ftp/swisseph

Added:
- swejni.c
- swejni.h

# Swiss Ephemeris License

Please make sure before you use the project you are familiar with the Swiss Ephemeris License
https://www.astro.com/swisseph/swephinfo_e.htm
https://www.astro.com/swisseph/secont_e.htm

If you want the Swiss Ephemeris Free Edition for your software project, please proceed as follows:
- make sure you understand the License conditions
- download the software
- start programming