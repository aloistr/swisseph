RadixPro version 0.9

This archive contains the source of RadixPro version 0.0

In the folder 'visualstudio' you will find the source for the Express edition of Visual Studio 2008.
This folder also contains the resources.

The folder 'font' contains three fonts that need to be isntalled manually. Just copy them to the font-folder of Windows.

Help files in HTML-format are placed in the folder 'help', this folder also contains a compiled help-version 'radixpro.chm'.

This application uses the dutch language. Texts are defined in a resouce bundle. 
An english version of the resourcebundle is available in the file 'en_resoucebundle.cs'.

The help texts are at this time only available in dutch.

RadixPro is open source. Please see the headers of the source files.


For more information: http://www.radixpro.org
For the compiled application: http://www.radixpro.nl








