1) modSwedll32.bas     - Contains Swiss Ephemeris API Declarations for Visual Basic 32-bit.
2) clsTestSwedll32.cls - Test subroutines for Swiss Ephemeris Visual Basic 32-bit API functions.
3) modTestSwedll32.bas - Test module to call Test subroutines defined in the above class module.
4) Swedll32.xls        - Includes all the above standard/Class module files in Excel VBA Project 
                         to use/test Swiss Ephemeris Visual Basic 32-bit API Declared functions.
5) TestSwedll32.txt    - Sample output file showing Test results.
'=================================================================
' Created by        :D.Senthilathiban (Email:athi_ram@yahoo.com)
' from posting in Swiss Ephemeris mailing list
'=================================================================

